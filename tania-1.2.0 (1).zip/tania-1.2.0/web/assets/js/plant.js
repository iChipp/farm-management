jQuery.datetimepicker.setLocale(global.locale);
$(".date-picker").datetimepicker({
    format: 'Y-m-d',
    timepicker: false
});
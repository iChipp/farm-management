jQuery.datetimepicker.setLocale(global.locale);
$(".date-time-picker").datetimepicker({
    format: 'Y-m-d H:i'
});
